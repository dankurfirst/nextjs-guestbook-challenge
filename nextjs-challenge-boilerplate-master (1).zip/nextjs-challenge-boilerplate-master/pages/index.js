export default () => (
  <div>NextJS App is running</div>
)
